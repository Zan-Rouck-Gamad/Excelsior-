function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}

function check() {
    var arrans = ["Style","Selector","Property","Value","Internal","External","Inline"
    ,"#","."];
    var arrquestions = document.getElementsByClassName("divq");
    var resultcontainer = document.getElementById("results");
    var score = 0;
    for (i = 0 ; i < arrquestions.length ;i++) {
        if (i >= 4 && i <= 6) {
            if (arrquestions[i].innerText === arrans[4] || arrquestions[i].innerText === arrans[5] 
            || arrquestions[i].innerText === arrans[6]) {
                score +=1;
            }
        }
        if (arrans[i] === arrquestions[i].innerText && (i < 4 || i > 6)) {
            score += 1;
        }
    }
    resultcontainer.innerHTML = score + " out of " + arrans.length;
}