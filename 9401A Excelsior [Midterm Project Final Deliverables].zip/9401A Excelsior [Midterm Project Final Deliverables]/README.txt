Open index.html
